/*
** EPITECH PROJECT, 2020
** sokoban.h
** File description:
** sokoban
*/

#ifndef  MY_SOKOBAN_H
#define  MY_SOKOBAN_H

#include <curses.h>
#include <ncurses.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

typedef struct my_map {
    int line;
    int column;
    int p_line;
    int p_cols;
    int nb_x;
    int nb_o;
    int nb_of_corner;
    int **pos_of_x;
    int **pos_of_o;
    char **my_map;
} sokoban_t;

///////////////LIB///////////////

void my_swap(int *, int *);
void my_sort_int_array(int *, int);
void my_putchar(char);
int my_showmem(char const *, int);
int my_getnbr(char const *);
int my_isneg(int);
int my_is_prime(int);
int my_put_nbr(int);
int my_showstr(char const *);
int my_putstr(char const *);
int my_strlen(char const *);
int my_strcmp(char const *, char const *);
int my_strncmp(char const *, char const *, int);
char *my_revstr(char *);
char *my_strcat(char *, char *);
char *my_strncat(char *, char const *, int);
char *my_strcpy(char *, char const *);
char *my_strncpy(char *, char const *, int);
char *my_strstr(char *, char const *);
char *my_strcapitalize(char *);
char *my_strlowcase(char *);
char *my_strupcase(char *);
char *my_strdup(char const *);
int my_str_isalpha(char const *);
int my_str_islower(char const *);
int my_str_isnum(char const *);
int my_str_isprintable(char const *);
int my_str_isupper(char const *);
int my_compute_power_rec(int, int);
int my_compute_square_root(int);
int my_find_prime_sup(int);

////////////////////MY_PRINTF////////////////////

int my_putchar_va_list(va_list list);
int my_putstr_va_list(va_list list);
int my_put_nbr_unsigned_va_list(va_list list);
int my_octal(va_list list);
int my_binary(va_list list);
int my_percentage_va_list(va_list list);
int my_hex_upper(va_list list);
int my_hex_lower(va_list list);
int my_p_va_list(va_list list);
int my_put_nbr_x_lower(int nb);
int my_put_nbr_x_upper(int nb);
int my_p(int nb);
int my_printf(char const *str, ...);
int my_put_nbr_binary(int);
char *my_strdup(char const *src);
long my_put_nbr_long(long);
unsigned int my_put_nbr_unsigned(unsigned int);
unsigned int my_put_nbr_octal(unsigned int);

////////////////SOKOBAN////////////////

char *read_map(char const *map);
int main(int ac, char **av);
int win(sokoban_t *stru);
int lose(sokoban_t *stru);
int nb_cols(sokoban_t *stru, char *str);
int nb_rows(sokoban_t *stru, char *str);
int wrong_map(int ac, char **av);
int gest_error(int ac, char **av);
void found_nb_o(sokoban_t *stru, int ac, char **av);
void my_o(sokoban_t *stru);
void my_x(sokoban_t *stru);
void o_is_back(sokoban_t *stru);
void new_map(char *str, sokoban_t *stru);
void found_nb_x(sokoban_t *stru, int ac, char **av);
void flag_h(void);
void all_functions(sokoban_t *stru, int ac, char **av);
void print_map(sokoban_t *stru);
void stock_pos_of_x(sokoban_t *stru);
void key_left(sokoban_t *stru, int ac, char **av);
void key_right(sokoban_t *stru, int ac, char **av);
void key_up(sokoban_t *stru, int ac, char **av);
void key_down(sokoban_t *stru, int ac, char **av);
void player_p(sokoban_t *stru, int ac, char **av);
void nb_of_corner(sokoban_t *stru);

#endif
