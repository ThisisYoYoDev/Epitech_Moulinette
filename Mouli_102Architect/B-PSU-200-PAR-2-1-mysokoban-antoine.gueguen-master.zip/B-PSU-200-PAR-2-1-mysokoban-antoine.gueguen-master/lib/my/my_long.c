/*
** EPITECH PROJECT, 2020
** long.c
** File description:
** long
*/

#include "my_printf.h"

void my_putchar(char c);

long my_put_nbr_long(long nb);

int my_long(va_list list)
{
    long nb = va_arg(list, long);

    if (nb < 0) {
        nb = -nb;
        my_putchar('-');
    }
    if (nb >= 10)
        my_put_nbr_long(nb/10);
    my_putchar((nb % 10) + '0');
}