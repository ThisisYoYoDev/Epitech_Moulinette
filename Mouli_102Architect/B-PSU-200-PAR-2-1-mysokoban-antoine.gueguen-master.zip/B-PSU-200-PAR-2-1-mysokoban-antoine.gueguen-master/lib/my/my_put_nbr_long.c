/*
** EPITECH PROJECT, 2020
** my_put_nbr_long.c
** File description:
** my_put_nbr_long
*/

void my_putchar(char c);

long my_put_nbr_long(long nb)
{
    if (nb < 0) {
        nb = -nb;
        my_putchar('-');
    }
    if (nb >= 10)
        my_put_nbr_long(nb/10);
    my_putchar((nb % 10) + '0');
}
