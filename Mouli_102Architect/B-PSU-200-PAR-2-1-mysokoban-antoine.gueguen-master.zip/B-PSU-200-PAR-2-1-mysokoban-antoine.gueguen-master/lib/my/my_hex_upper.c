/*
** EPITECH PROJECT, 2020
** hex_upper.c
** File description:
** hex_upper
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr_x_upper(int nb);

int my_hex_upper(va_list list)
{
    my_put_nbr_x_upper(va_arg(list, int));
    return 0;
}