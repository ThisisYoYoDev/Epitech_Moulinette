/*
** EPITECH PROJECT, 2020
** my_revstr
** File description:
** lib revstr
*/

void my_putchar(char c);

int my_strlen(const char *str);

char *my_revstr(char *str)
{
    int a;
    int b = my_strlen(str) - 1;
    char swap;

    for (a = 0; a < b; a++) {
        swap = str[a];
        str[a] = str[b];
        str[b] = swap;
        b--;
    }
    return (str);
}
