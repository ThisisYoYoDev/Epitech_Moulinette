/*
** EPITECH PROJECT, 2020
** lib my_strcapitalize
** File description:
** my_strcapitalize
*/

char *my_strcapitalize(char *str)
{
    return (0);
}
