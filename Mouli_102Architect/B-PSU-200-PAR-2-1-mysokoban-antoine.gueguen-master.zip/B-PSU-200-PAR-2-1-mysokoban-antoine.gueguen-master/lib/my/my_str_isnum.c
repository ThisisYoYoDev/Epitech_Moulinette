/*
** EPITECH PROJECT, 2020
** lib my_str_isnum
** File description:
** my_str_isnum
*/

int my_str_isnum(char const *str)
{
    return (0);
}
