/*
** EPITECH PROJECT, 2020
** octal.c
** File description:
** octal
*/

#include "my_printf.h"

void my_putchar(char c);

unsigned int my_put_nbr_octal(unsigned int nb);

int my_octal(va_list list)
{
    unsigned int nb = va_arg(list, unsigned int);

    if (nb >= 8)
        my_put_nbr_octal(nb / 8);
    my_putchar((nb % 8) + '0');
}
