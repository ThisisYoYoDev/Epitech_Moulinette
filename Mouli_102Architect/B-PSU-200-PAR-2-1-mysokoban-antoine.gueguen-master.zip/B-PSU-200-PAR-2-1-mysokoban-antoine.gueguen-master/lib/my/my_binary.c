/*
** EPITECH PROJECT, 2020
** binary.c
** File description:
** binary
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr_binary(int nb);

int my_binary(va_list list)
{
    int nb = va_arg(list, int);

    if (nb >= 2)
        my_put_nbr_binary(nb / 2);
    my_putchar((nb % 2) + '0');
}