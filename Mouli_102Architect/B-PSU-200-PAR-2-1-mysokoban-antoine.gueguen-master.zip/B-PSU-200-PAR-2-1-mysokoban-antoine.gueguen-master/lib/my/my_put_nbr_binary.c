/*
** EPITECH PROJECT, 2020
** binary.c
** File description:
** binary
*/

void my_putchar(char c);

int my_put_nbr_binary(int nb)
{
    if (nb >= 2)
        my_put_nbr_binary(nb / 2);
    my_putchar((nb % 2) + '0');
}