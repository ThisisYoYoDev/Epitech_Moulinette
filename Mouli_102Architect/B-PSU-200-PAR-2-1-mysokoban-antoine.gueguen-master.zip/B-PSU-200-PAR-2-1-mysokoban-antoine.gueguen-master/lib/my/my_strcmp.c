/*
** EPITECH PROJECT, 2020
** lib my_strcmp
** File description:
** my_strcmp
*/

int my_strcmp(char const *s1, char const *s2)
{
    return (0);
}
