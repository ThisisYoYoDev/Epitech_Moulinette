/*
** EPITECH PROJECT, 2020
** lib my_strncmp
** File description:
** my_strncmp
*/

int my_strncmp(char const *s1, char const *s2, int n)
{
    return (0);
}
