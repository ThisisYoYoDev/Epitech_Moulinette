/*
** EPITECH PROJECT, 2020
** putchar_va_list.c
** File description:
** putchar_va_list
*/

#include "my_printf.h"

int my_putchar_va_list(va_list list)
{
    char c = va_arg(list, int);

    write(1, &c, 1);
}