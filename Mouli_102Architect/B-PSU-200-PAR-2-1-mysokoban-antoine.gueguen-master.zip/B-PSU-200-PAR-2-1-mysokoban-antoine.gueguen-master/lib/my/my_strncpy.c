/*
** EPITECH PROJECT, 2020
**  lib my_strcpy
** File description:
** my_strcpy
*/

char *my_strncpy(char *dest, char const *src, int n)
{
    return (0);
}