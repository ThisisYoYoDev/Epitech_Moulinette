/*
** EPITECH PROJECT, 2020
** lib my_strncat
** File description:
** my_strncat
*/

char *my_strncat(char *dest, char const *src, int nb)
{
    return (0);
}
