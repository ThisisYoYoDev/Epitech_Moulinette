/*
** EPITECH PROJECT, 2020
** c.c
** File description:
** c
*/

#include "my_printf.h"

int my_printf(char const *str, ...)
{
    va_list list;
    va_start(list, str);
    int x = 0;
    int i = 0;
    char flag[] = {'c', 's', 'u', 'o', 'd', 'i', 'b', 'X', 'x', 'p', '%', 'l'};
    int (*put[])(va_list) = {my_putchar_va_list, my_putstr_va_list,
    my_put_nbr_unsigned_va_list, my_octal, my_nbr, my_nbr, my_binary,
    my_hex_upper, my_hex_lower, my_p_va_list, my_percentage_va_list, my_long};

    while (str[x] != '\0') {
        if (str[x] == '%') {
            x++;
            for (i = 0; flag[i] != str[x]; i++);
            put[i](list);
        } else
            my_putchar(str[x]);
        x++;
    }
    va_end(list);
    return (0);
}