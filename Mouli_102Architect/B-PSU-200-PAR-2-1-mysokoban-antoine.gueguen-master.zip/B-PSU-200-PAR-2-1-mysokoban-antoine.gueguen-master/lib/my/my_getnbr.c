/*
** EPITECH PROJECT, 2020
** test
** File description:
** I will remove that
*/

#include "my_printf.h"

int my_getnbr(char const *str)
{
    int i = 0;
    int stock = 0;

    for (; str[i]; i++) {
        if (str[i] >= '0' && str[i] <= '9') {
            stock = ((stock * 10) + (str[i] - '0'));
        }
    }
    return (stock);
}