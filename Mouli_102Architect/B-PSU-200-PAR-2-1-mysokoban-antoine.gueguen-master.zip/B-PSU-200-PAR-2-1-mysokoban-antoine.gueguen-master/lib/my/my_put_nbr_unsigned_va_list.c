/*
** EPITECH PROJECT, 2020
** my_put_nbr_unsigned.c
** File description:
** my_put_nbr_unsigned
*/

#include "my_printf.h"

void my_putchar(char c);

unsigned my_put_nbr_unsigned(unsigned int nb);

int my_put_nbr_unsigned_va_list(va_list list)
{
    unsigned int nb = va_arg(list, unsigned int);

    if (nb >= 10)
        my_put_nbr_unsigned(nb / 10);
    my_putchar((nb % 10) + '0');
}