/*
** EPITECH PROJECT, 2020
** lib my_str_islower
** File description:
** my_islower
*/

int my_str_islower(char const *str)
{
    return (0);
}
