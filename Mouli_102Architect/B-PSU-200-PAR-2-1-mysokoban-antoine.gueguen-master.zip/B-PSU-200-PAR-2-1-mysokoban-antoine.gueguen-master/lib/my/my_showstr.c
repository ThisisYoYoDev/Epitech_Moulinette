/*
** EPITECH PROJECT, 2020
** lib my_showstr
** File description:
** my_showstr
*/

int my_showstr(char const *str)
{
    return (0);
}
