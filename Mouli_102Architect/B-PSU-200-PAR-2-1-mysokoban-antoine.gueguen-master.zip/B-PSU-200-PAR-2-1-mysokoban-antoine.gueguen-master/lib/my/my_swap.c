/*
** EPITECH PROJECT, 2020
** lib my_swap
** File description:
** lib my_swap
*/

void my_swap(int *a, int *b)
{
    int c;

    c = *a;
    *a = *b;
    *b = c;
}
