/*
** EPITECH PROJECT, 2020
** lib my_find_prime_sup
** File description:
** my_find_prime_sup
*/

int my_find_prime_sup(int nb)
{
    return (0);
}
