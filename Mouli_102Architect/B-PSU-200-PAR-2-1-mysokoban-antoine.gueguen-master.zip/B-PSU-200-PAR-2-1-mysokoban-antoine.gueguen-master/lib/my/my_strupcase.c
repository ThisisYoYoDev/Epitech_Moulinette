/*
** EPITECH PROJECT, 2020
** lib my_strupcase
** File description:
** my_strupcase
*/

char *my_strupcase(char *str)
{
    return (0);
}
