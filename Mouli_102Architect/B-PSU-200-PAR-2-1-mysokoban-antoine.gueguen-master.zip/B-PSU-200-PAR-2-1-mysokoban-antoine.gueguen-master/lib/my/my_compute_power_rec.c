/*
** EPITECH PROJECT, 2020
** my_compute_power_rec
** File description:
** lib my_compute_power_rec
*/

int my_compute_power_rec(int nb, int power)
{
    return (0);
}
