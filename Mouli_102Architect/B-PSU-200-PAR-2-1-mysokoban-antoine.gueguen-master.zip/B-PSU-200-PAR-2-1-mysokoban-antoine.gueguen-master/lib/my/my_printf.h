/*
** EPITECH PROJECT, 2020
** my_printf.h
** File description:
** my_printf
*/

#ifndef  MY_PRINTF_H_
#define  MY_PRINTF_H_

#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

#define CTOI(x) (x - '0')
#define ITOC(x) (x + '0')

int my_compute_power_rec(int, int);
int my_compute_square_root(int);
int my_find_prime_sup(int);
int my_getnbr(char const *);
int my_isneg(int);
int my_is_prime(int);
int my_put_nbr(int);
unsigned int my_put_nbr_octal(unsigned int);
int my_put_nbr_binary(int);
void my_swap(int *, int *);
int my_showmem(char const *, int);
int my_showstr(char const *);
void my_sort_int_array(int *, int);
void my_putchar(char);
int my_putstr(char const *);
char *my_revstr(char *);
int my_strlen(char const *);
char *my_strcat(char *, char *);
char *my_strncat(char *, char const *, int);
int my_strcmp(char const *, char const *);
int my_strncmp(char const *, char const *, int);
char *my_strcpy(char *, char const *);
char *my_strncpy(char *, char const *, int);
char *my_strstr(char *, char const *);
int my_str_isalpha(char const *);
int my_str_islower(char const *);
int my_str_isnum(char const *);
int my_str_isprintable(char const *);
int my_str_isupper(char const *);
char *my_strcapitalize(char *);
char *my_strlowcase(char *);
char *my_strupcase(char *);
char *my_strdup(char const *);
long my_put_nbr_long(long);
int my_putchar_va_list(va_list list);
int my_putstr_va_list(va_list list);
int my_put_nbr_unsigned_va_list(va_list list);
unsigned int my_put_nbr_unsigned(unsigned int);
int my_octal(va_list list);
int my_long(va_list list);
int my_nbr(va_list list);
int my_binary(va_list list);
int my_printf(char const *str, ...);
char *my_strdup(char const *src);
int my_percentage_va_list(va_list list);
int my_put_nbr_x_upper(int nb);
int my_hex_upper(va_list list);
int my_put_nbr_x_lower(int nb);
int my_hex_lower(va_list list);
int my_p(int nb);
int my_p_va_list(va_list list);

#endif