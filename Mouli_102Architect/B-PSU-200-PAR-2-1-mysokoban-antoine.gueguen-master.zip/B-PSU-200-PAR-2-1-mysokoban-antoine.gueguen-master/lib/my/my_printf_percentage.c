/*
** EPITECH PROJECT, 2020
** percentage.
** File description:
** percentage
*/

#include "my_printf.h"

int my_percentage_va_list(va_list list)
{
    my_putchar('%');
    return 0;
}