/*
** EPITECH PROJECT, 2020
** lib my_str_isupper
** File description:
** my_str_isupper
*/

int my_str_isupper(char const *str)
{
    return (0);
}
