/*
** EPITECH PROJECT, 2020
** lib ly_strcat
** File description:
** my_strcat
*/

char *my_strcat(char *dest, char const *src)
{
    return (0);
}
