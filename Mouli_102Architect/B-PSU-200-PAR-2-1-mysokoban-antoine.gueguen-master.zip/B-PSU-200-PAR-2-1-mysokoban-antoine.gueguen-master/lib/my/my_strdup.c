/*
** EPITECH PROJECT, 2020
** my_strdup
** File description:
** that allocates memory and copies the string given as argument in it.
*/

#include "my_printf.h"

void my_putchar(char c);

int my_strlen(char const *str);

char *my_strdup(char const *src)
{
    char *str;
    int i = 0;
    int b = my_strlen(src);

    str = malloc(sizeof(char) * (b + 1));
    while (i != b) {
        str[i] = src[i];
        i = i + 1;
    }
    str[i] = '\0';
    return (str);
}
