/*
** EPITECH PROJECT, 2020
** my_sort_int_array
** File description:
** lib my_sort_array
*/

void my_sort_int_array(int *tab, int size)
{
    return;
}
