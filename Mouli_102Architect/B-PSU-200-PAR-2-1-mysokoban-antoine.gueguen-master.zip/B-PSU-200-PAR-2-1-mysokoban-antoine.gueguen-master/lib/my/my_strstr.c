/*
** EPITECH PROJECT, 2020
** lib my_strstr
** File description:
** my_strstr
*/

char *my_strstr(char *str, char const *to_find)
{
    return (0);
}
