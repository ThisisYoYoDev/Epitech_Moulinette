/*
** EPITECH PROJECT, 2020
** lib my_str_isalpha
** File description:
** my_str_isalpha
*/

int my_str_isalpha(char const *str)
{
    return (0);
}
