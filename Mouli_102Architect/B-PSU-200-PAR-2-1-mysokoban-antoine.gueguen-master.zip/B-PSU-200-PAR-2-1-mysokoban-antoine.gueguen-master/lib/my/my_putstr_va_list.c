/*
** EPITECH PROJECT, 2020
** put_str_valist
** File description:
** putstrvalost
*/

#include "my_printf.h"

int my_putstr_va_list(va_list list)
{
    int i = 0;
    char *str = va_arg(list, char *);

    while (str[i] != '\0') {
        my_putchar(str[i]);
        i = i + 1;
    }
    return (0);
}