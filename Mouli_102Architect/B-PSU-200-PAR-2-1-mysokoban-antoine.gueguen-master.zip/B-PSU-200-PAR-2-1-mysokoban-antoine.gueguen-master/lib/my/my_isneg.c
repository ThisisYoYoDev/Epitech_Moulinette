/*
** EPITECH PROJECT, 2020
** lib my isneg
** File description:
** lib my_isneg
*/

void my_putchar(char c);

int my_isneg(int nb)
{
    if (nb >= 0) {
        my_putchar('P');
    } else {
        my_putchar('N');
        my_putchar('\n');
        return (0);
    }
}
