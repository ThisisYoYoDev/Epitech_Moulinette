/*
** EPITECH PROJECT, 2020
** lib my_showmem
** File description:
** my_showmem
*/

int my_showmem(char const *str, int size)
{
    return (0);
}
