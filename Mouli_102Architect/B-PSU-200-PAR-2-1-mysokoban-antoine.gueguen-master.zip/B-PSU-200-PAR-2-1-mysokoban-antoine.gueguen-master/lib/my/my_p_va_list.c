/*
** EPITECH PROJECT, 2020
** my_p_va_list.c
** File description:
** my_p_va_list
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr_x_lower(int nb);

int my_p(int nb);

int my_p_va_list(va_list list)
{
    my_p(va_arg(list, int));
    return 0;
}