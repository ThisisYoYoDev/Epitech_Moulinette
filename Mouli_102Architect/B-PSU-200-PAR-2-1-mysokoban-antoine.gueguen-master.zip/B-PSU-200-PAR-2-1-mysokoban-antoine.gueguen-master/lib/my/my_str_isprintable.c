/*
** EPITECH PROJECT, 2020
** lib my_str_isprintable
** File description:
** my_str_isprintable
*/

int my_str_isprintable(char const *str)
{
    return (0);
}
