/*
** EPITECH PROJECT, 2020
** lib my_is_prime
** File description:
** my_is_prime
*/

int my_is_prime(int nb)
{
    return (0);
}
