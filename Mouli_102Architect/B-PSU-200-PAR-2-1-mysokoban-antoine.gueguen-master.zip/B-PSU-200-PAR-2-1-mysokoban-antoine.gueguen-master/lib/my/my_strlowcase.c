/*
** EPITECH PROJECT, 2020
** lib my_strlowcase
** File description:
** my_strlowcase
*/

char *my_strlowcase(char *str)
{
    return (0);
}
