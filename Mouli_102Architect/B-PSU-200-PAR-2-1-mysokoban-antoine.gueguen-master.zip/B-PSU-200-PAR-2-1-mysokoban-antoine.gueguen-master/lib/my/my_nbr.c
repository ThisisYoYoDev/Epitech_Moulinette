/*
** EPITECH PROJECT, 2020
** nbr.c
** File description:
** nbr
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr(int nb);

int my_nbr(va_list list)
{
    int nb = va_arg(list, int);

    if (nb < 0) {
        nb = -nb;
        my_putchar('-');
    }
    if (nb >= 10) {
        my_put_nbr(nb / 10);
        my_putchar((nb % 10) + '0');
    }
    if (nb <= 9)
        my_putchar(nb + 48);
}