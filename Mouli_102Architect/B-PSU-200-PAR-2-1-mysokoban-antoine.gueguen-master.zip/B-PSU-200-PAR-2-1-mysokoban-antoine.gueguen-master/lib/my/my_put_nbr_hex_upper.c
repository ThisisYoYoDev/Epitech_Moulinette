/*
** EPITECH PROJECT, 2020
** hex_upper.c
** File description:
** hex_upper
*/

#include "my_printf.h"

int my_put_nbr_x_upper(int nb)
{
    int result;

    if (nb >= 16) {
        result = (nb % 16);
        nb = (nb / 16);
        my_put_nbr_x_upper(nb);
    }
    else if (nb >= 0) {
        result = (nb % 16);
        nb = (nb / 16);
    }
    if (result > 9)
        my_putchar(result + 55);
    else
        my_putchar(result + 48);
}
