/*
** EPITECH PROJECT, 2020
** hex_lower.c
** File description:
** hex_lower
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr_x_lower(int nb);

int my_hex_lower(va_list list)
{
    my_put_nbr_x_lower(va_arg(list, int));
    return 0;
}