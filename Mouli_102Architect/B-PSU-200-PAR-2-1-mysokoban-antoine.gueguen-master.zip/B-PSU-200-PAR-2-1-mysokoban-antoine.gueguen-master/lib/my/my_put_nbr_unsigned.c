/*
** EPITECH PROJECT, 2020
** dzdz
** File description:
** dzdz
*/

void my_putchar(char c);

unsigned int my_put_nbr_unsigned(unsigned int nb)
{
    if (nb >= 10)
        my_put_nbr_unsigned(nb / 10);
    my_putchar((nb % 10) + '0');
}