/*
** EPITECH PROJECT, 2020
** my_p.c
** File description:
** my_p
*/

#include "my_printf.h"

void my_putchar(char c);

int my_put_nbr_x_lower(int nb);

int my_p(int nb)
{
    my_putchar('0');
    my_putchar('x');
    my_put_nbr_x_lower(nb);
}