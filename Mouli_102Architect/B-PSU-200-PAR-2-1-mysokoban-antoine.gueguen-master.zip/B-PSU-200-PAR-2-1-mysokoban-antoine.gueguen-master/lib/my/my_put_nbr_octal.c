/*
** EPITECH PROJECT, 2020
** my_put_nbr_octal.c
** File description:
** my_put_nbr_octal
*/

#include "my_printf.h"

void my_putchar(char c);

unsigned int my_put_nbr_octal(unsigned int nb)
{
    if (nb >= 8)
        my_put_nbr_octal(nb / 8);
    my_putchar((nb % 8) + '0');
}