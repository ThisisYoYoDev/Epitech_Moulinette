/*
** EPITECH PROJECT, 2021
** grouping_of_functions.c
** File description:
** grouping_of_functions
*/

#include "sokoban.h"

void all_functions(sokoban_t *stru, int ac, char **av)
{
    char *buffer = read_map(av[1]);

    nb_rows(stru, buffer);
    nb_cols(stru, buffer);
    new_map(buffer, stru);
    player_p(stru, ac, av);
    found_nb_o(stru, ac, av);
    found_nb_x(stru, ac, av);
    nb_of_corner(stru);
    my_o(stru);
    my_x(stru);
    initscr();
    noecho();
    curs_set(0);
    keypad(stdscr, TRUE);
}