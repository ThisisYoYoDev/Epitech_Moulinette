/*
** EPITECH PROJECT, 2021
** gest_error.c
** File description:
** gest_error
*/

#include "sokoban.h"

int wrong_map(int ac, char **av)
{
    char *buff = read_map(av[1]);

    for (int i = 0; buff[i] != '\0'; i++) {
        if (buff[i] != ' ' && buff[i] != 'P' && buff[i] != 'O' &&
            buff[i] != 'X' && buff[i] != '\n' && buff[i] != '#')
            return 84;
    }
    return 0;
}

int gest_error(int ac, char **av)
{
    if (ac != 2)
        return 84;
    if (wrong_map(ac, av) == 84)
        return 84;
    return 0;
}
