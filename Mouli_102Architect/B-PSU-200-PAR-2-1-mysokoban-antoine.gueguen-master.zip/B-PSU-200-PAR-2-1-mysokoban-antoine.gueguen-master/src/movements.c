/*
** EPITECH PROJECT, 2021
** movements.c
** File description:
** movement
*/

#include "sokoban.h"

void key_left(sokoban_t *stru, int ac, char **av)
{
    char *buffer = read_map(av[1]);

    if (stru->my_map[stru->p_line][stru->p_cols - 1] != '#') {
        if (stru->my_map[stru->p_line][stru->p_cols - 1] == 'X' &&
            stru->my_map[stru->p_line][stru->p_cols - 2] != 'X' &&
            stru->my_map[stru->p_line][stru->p_cols - 2] != '#') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line][stru->p_cols - 1] = 'P';
            stru->my_map[stru->p_line][stru->p_cols - 2] = 'X';
            stru->p_cols = stru->p_cols - 1;
        } else if (stru->my_map[stru->p_line][stru->p_cols - 1] == ' ' ||
            stru->my_map[stru->p_line][stru->p_cols - 1] == 'O') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line][stru->p_cols - 1] = 'P';
            stru->p_cols = stru->p_cols - 1;
        }
    }
}

void key_right(sokoban_t *stru, int ac, char **av)
{
    char *buffer = read_map(av[1]);

    if (stru->my_map[stru->p_line][stru->p_cols + 1] != '#') {
        if (stru->my_map[stru->p_line][stru->p_cols + 1] == 'X' &&
            stru->my_map[stru->p_line][stru->p_cols + 2] != 'X' &&
            stru->my_map[stru->p_line][stru->p_cols + 2] != '#') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line][stru->p_cols + 1] = 'P';
            stru->my_map[stru->p_line][stru->p_cols + 2] = 'X';
            stru->p_cols = stru->p_cols + 1;
        } else if (stru->my_map[stru->p_line][stru->p_cols + 1] == ' ' ||
            stru->my_map[stru->p_line][stru->p_cols + 1] == 'O') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line][stru->p_cols + 1] = 'P';
            stru->p_cols = stru->p_cols + 1;
        }
    }
}

void key_up(sokoban_t *stru, int ac, char **av)
{
    char *buffer = read_map(av[1]);

    if (stru->my_map[stru->p_line - 1][stru->p_cols] != '#') {
        if (stru->my_map[stru->p_line - 1][stru->p_cols] == 'X' &&
            stru->my_map[stru->p_line - 2][stru->p_cols] != 'X' &&
            stru->my_map[stru->p_line - 2][stru->p_cols] != '#') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line - 1][stru->p_cols] = 'P';
            stru->my_map[stru->p_line - 2][stru->p_cols] = 'X';
            stru->p_line = stru->p_line - 1;
        } else if (stru->my_map[stru->p_line - 1][stru->p_cols] == ' ' ||
            stru->my_map[stru->p_line - 1][stru->p_cols] == 'O') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line - 1][stru->p_cols] = 'P';
            stru->p_line = stru->p_line - 1;
        }
    }
}

void key_down(sokoban_t *stru, int ac, char **av)
{
    char *buffer = read_map(av[1]);

    if (stru->my_map[stru->p_line + 1][stru->p_cols] != '#') {
        if (stru->my_map[stru->p_line + 1][stru->p_cols] == 'X' &&
            stru->my_map[stru->p_line + 2][stru->p_cols] != 'X' &&
            stru->my_map[stru->p_line + 2][stru->p_cols] != '#') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line + 1][stru->p_cols] = 'P';
            stru->my_map[stru->p_line + 2][stru->p_cols] = 'X';
            stru->p_line = stru->p_line + 1;
        } else if (stru->my_map[stru->p_line + 1][stru->p_cols] == ' ' ||
            stru->my_map[stru->p_line + 1][stru->p_cols] == 'O') {
            stru->my_map[stru->p_line][stru->p_cols] = ' ';
            stru->my_map[stru->p_line + 1][stru->p_cols] = 'P';
            stru->p_line = stru->p_line + 1;
        }
    }
}
