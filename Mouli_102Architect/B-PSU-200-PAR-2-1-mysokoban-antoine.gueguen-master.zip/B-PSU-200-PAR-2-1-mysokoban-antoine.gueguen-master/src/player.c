/*
** EPITECH PROJECT, 2021
** player.c
** File description:
** player
*/

#include "sokoban.h"

void player_p(sokoban_t *stru, int ac, char **av)
{
    int x = 0;
    int y = 0;
    char *str = read_map(av[1]);

    stru->p_line = 0;
    stru->p_cols = 0;
    nb_rows(stru, str);
    nb_cols(stru, str);
    new_map(str, stru);
    for (; x < stru->line; x++) {
        for (; y < (stru->column); y++) {
            if (stru->my_map[x][y] == 'P') {
                stru->p_line = x;
                stru->p_cols = y;
            }
        }
        y = 0;
    }
}