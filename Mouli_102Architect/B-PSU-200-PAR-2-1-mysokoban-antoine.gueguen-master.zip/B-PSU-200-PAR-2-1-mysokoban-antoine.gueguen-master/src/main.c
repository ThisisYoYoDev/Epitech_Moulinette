/*
** EPITECH PROJECT, 2021
** main.c
** File description:
** main
*/

#include "sokoban.h"

static const int NB_CHAR_ERROR_MSG = 15;

void print_map(sokoban_t *stru)
{
    WINDOW *low = subwin(stdscr, LINES / 2, COLS / 2, LINES / 2,
                        (COLS - NB_CHAR_ERROR_MSG) / 2);

    for (int y = 0; y < stru->line + 1; y++) {
        if (stru->line > LINES || stru->column > COLS) {
            mvwprintw(low, 0, 0, "Expand screen");
            break;
        }
        mvprintw((LINES / 2) + y - (stru->line / 2),
                (COLS - stru->column) / 2, "%s", stru->my_map[y]);
    }
}

int cond_win_or_lose(sokoban_t *stru)
{
    if (win(stru) == 0) {
        endwin();
        return 0;
    }
    if (lose(stru) == 1) {
        endwin();
        return 1;
    }
}

int game_loop(sokoban_t *stru, int ac, char **av)
{
    for (int key; key != ' '; ) {
        wclear(stdscr);
        if (key == KEY_DOWN)
            key_down(stru, ac, av);
        if (key == KEY_UP)
            key_up(stru, ac, av);
        if (key == KEY_LEFT)
            key_left(stru, ac, av);
        if (key == KEY_RIGHT)
            key_right(stru, ac, av);
        o_is_back(stru);
        if (cond_win_or_lose(stru) == 0)
            return 0;
        if (cond_win_or_lose(stru) == 1)
            return 1;
        print_map(stru);
        refresh();
        key = getch();
    }
    main(ac, av);
}

int main(int ac, char **av)
{
    sokoban_t *stru = malloc(sizeof(sokoban_t));
    char *buffer = read_map(av[1]);

    if (ac == 2) {
        if (av[1][0] == '-' && av[1][1] == 'h') {
            flag_h();
            return 0;
        }
    }
    if (gest_error(ac, av) == 84)
        return 84;
    all_functions(stru, ac, av);
    game_loop(stru, ac, av);
    if (win(stru) == 0)
        return 0;
    if (lose(stru) == 1)
        return 1;
}