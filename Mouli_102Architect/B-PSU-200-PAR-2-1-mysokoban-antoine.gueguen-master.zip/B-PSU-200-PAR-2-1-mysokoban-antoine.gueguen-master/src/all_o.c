/*
** EPITECH PROJECT, 2021
** all_o.c
** File description:
** all_o
*/

#include "sokoban.h"

void found_nb_o(sokoban_t *stru, int ac, char **av)
{
    char *buff = read_map(av[1]);
    int u = 0;

    stru->nb_o = 0;
    for (int i = 0; buff[i] != '\0'; i++) {
        if (buff[i] == 'O')
            u++;
    }
    stru->nb_o = u;
}

void my_o(sokoban_t *stru)
{
    int i = 0;
    int y = 0;
    int cmp = 0;

    stru->pos_of_o = malloc(sizeof(int *) * stru->nb_o);
    for (; i < stru->line; i++) {
        for (; y < stru->column; y++) {
            if (stru->my_map[i][y] == 'O') {
                stru->pos_of_o[cmp] = malloc(sizeof(int) * 2);
                stru->pos_of_o[cmp][0] = i;
                stru->pos_of_o[cmp][1] = y;
                cmp++;
            }
        }
        y = 0;
    }
}

void o_is_back(sokoban_t *stru)
{
    for (int y = 0; y < stru->nb_o; y++) {
        if (stru->my_map[stru->pos_of_o[y][0]][stru->pos_of_o[y][1]] == ' ')
            stru->my_map[stru->pos_of_o[y][0]][stru->pos_of_o[y][1]] = 'O';
    }
}