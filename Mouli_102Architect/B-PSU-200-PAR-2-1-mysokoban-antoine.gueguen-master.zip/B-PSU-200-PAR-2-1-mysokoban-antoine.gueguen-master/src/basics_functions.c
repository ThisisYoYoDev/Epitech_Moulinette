/*
** EPITECH PROJECT, 2021
** basics_functions.c
** File description:
** basics_functions
*/

#include "sokoban.h"

char *read_map(char const *map)
{
    int fd = open(map, O_RDWR);
    char *buffer;
    int size;
    int read_map;
    struct stat size_t;

    stat(map, &size_t);
    size = size_t.st_size;
    buffer = malloc(sizeof(char) * size + 1);
    read_map = read(fd, buffer, size);
    buffer[read_map] = '\0';
    close(fd);
    return buffer;
}

int nb_cols(sokoban_t *stru, char *str)
{
    int i = 0;

    while (str[i] != '\n')
        i++;
    stru->column = i + 1;
}

int nb_rows(sokoban_t *stru, char *str)
{
    int n_rows = 0;
    int i = 0;

    while (str[i] != '\0') {
        if (str[i] == '\n')
            n_rows++;
        if (str[i] == '\n' && str[i + 1] == '\n')
            break;
        i++;
    }
    stru->line = n_rows;
}

void new_map(char *str, sokoban_t *stru)
{
    char **n_map = malloc(sizeof(char *) * (stru->line + 2));
    int y = 0;
    int i = 0;
    int u = 0;

    for (; i < (stru->line + 1); i++) {
        n_map[i] = malloc(sizeof(char) * (stru->column + 2));
        for (; y < (stru->column); y++) {
            n_map[i][y] = str[u];
            u++;
        }
        n_map[i][y] = '\0';
        y = 0;
    }
    n_map[i] = NULL;
    stru->my_map = n_map;
}

void found_nb_x(sokoban_t *stru, int ac, char **av)
{
    char *buff = read_map(av[1]);
    int u = 0;

    stru->nb_x = 0;
    for (int i = 0; buff[i] != '\0'; i++) {
        if (buff[i] == 'X')
            u++;
    }
    stru->nb_x = u;
}