/*
** EPITECH PROJECT, 2021
** flag_h.c
** File description:
** flag_h
*/

#include "sokoban.h"

void flag_h(void)
{
    my_printf("USAGE\n");
    my_printf("     ./my_sokoban map\n");
    my_printf("DESCRIPTION\n");
    my_printf("     map  file representing the warehouse");
    my_printf(" map, containing '#' for walls,\n");
    my_printf("          'P' for the player, 'X' for");
    my_printf(" boxes and 'O' for storage locations.\n");
}