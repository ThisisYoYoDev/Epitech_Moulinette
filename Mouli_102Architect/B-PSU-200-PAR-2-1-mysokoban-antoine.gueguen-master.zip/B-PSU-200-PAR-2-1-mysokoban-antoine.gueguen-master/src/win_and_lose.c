/*
** EPITECH PROJECT, 2021
** win_and_lose.c
** File description:
** win_and_lose
*/

#include "sokoban.h"

void nb_of_corner(sokoban_t *stru)
{
    int y = 0;
    int nb_corner = 0;

    stru->nb_of_corner = 0;
    for (int i = 0; i < stru->line; i++) {
        for (; y < stru->column; y++) {
            if (stru->my_map[i][y] == ' ' && stru->my_map[i - 1][y] == '#' &&
                stru->my_map[i][y - 1] == '#' && stru->my_map[i - 1][y - 1] ==
                '#' || stru->my_map[i][y] == ' ' && stru->my_map[i + 1][y] ==
                '#' && stru->my_map[i][y + 1] == '#' && stru->my_map[i + 1][y +
                1] == '#' || stru->my_map[i][y] == ' ' && stru->my_map[i + 1][y]
                == '#' && stru->my_map[i][y - 1] == '#' && stru->my_map[i + 1][y
                - 1] == '#' || stru->my_map[i][y] == ' ' && stru->my_map[i - 1][
                y] == '#' && stru->my_map[i][y + 1] == '#' &&
                stru->my_map[i - 1][y + 1] == '#') {
                nb_corner++;
            }
        }
        y = 0;
    }
    stru->nb_of_corner = nb_corner;
}

void my_x(sokoban_t *stru)
{
    int y = 0;
    int cmp = 0;

    stru->pos_of_x = malloc(sizeof(int *) * stru->nb_of_corner);
    for (int i = 0; i < stru->line; i++) {
        for (; y < stru->column; y++) {
            if (stru->my_map[i][y] == ' ' && stru->my_map[i - 1][y] == '#' &&
                stru->my_map[i][y - 1] == '#' && stru->my_map[i - 1][y - 1] ==
                '#' || stru->my_map[i][y] == ' ' && stru->my_map[i + 1][y] ==
                '#' && stru->my_map[i][y + 1] == '#' && stru->my_map[i + 1][y +
                1] == '#' || stru->my_map[i][y] == ' ' && stru->my_map[i + 1][y]
                == '#' && stru->my_map[i][y - 1] == '#' && stru->my_map[i + 1][y
                - 1] == '#' || stru->my_map[i][y] == ' ' && stru->my_map[i - 1][
                y] == '#' && stru->my_map[i][y + 1] == '#' &&
                stru->my_map[i - 1][y + 1] == '#') {
                stru->pos_of_x[cmp] = malloc(sizeof(int) * 2);
                stru->pos_of_x[cmp][0] = i;
                stru->pos_of_x[cmp][1] = y;
                cmp++;
            }
        }
        y = 0;
    }
}

int win(sokoban_t *stru)
{
    for (int y = 0; y < stru->nb_o; y++) {
        if (stru->my_map[stru->pos_of_o[y][0]][stru->pos_of_o[y][1]] != 'X')
            return 2;
    }
    return 0;
}

int lose(sokoban_t *stru)
{
    int u = 0;

    for (int y = 0; y < stru->nb_of_corner; y++) {
        if (stru->my_map[stru->pos_of_x[y][0]][stru->pos_of_x[y][1]] == 'X') {
            u++;
            if (u == stru->nb_x)
                return 1;
        }
    }
    return 2;
}